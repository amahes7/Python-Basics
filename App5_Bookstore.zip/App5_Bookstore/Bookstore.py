"""
This stores Title Author ISBN and year of the book
We can Add Select delete and update Entry.
"""

from tkinter import *
import DbOperations

def view_all():
    display_area.delete(0,END)
    records=DbOperations.display_all()
    for row in records:
        display_area.insert(END,row)

def insert():
        try:
                int(year_value.get())
                int(isbn_value.get())
                DbOperations.insert_record(title_value.get(),author_value.get(),year_value.get(),isbn_value.get())
                display_area.delete(0,END)
                display_area.insert(END,title_value.get(),author_value.get(),year_value.get(),isbn_value.get())
                for row in DbOperations.display_all():
                        display_area.insert(END,row)
        except TclError:
                display_area.delete(0,END)
                display_area.insert(0,"Enter year and isbn as integer")
                



def search():
    records=DbOperations.search_record (title_value.get(),author_value.get(),year_value.get(),isbn_value.get())
    display_area.delete(0,END)
    for row in records:
        display_area.insert(END,row)

def row_id(event):
    global selected_row
    global id
    try:
        index=display_area.curselection()[0]
        selected_row=display_area.get(index)
        id=selected_row[0]
        title_value.set(selected_row[1])
        author_value.set(selected_row[2])
        year_value.set(selected_row[3])
        isbn_value.set(selected_row[4])
    except IndexError:
        pass
    print(id)

def delete():
    DbOperations.delete_record(id)
    display_area.delete(0,END)
    display_area.insert(0,"Record Deleted!!")
    for row in DbOperations.display_all():
        display_area.insert(END,row)

def update():
        try:
                int(year_value.get())
                int(isbn_value.get())          
                DbOperations.update_record(id,title_value.get(),author_value.get(),year_value.get(),isbn_value.get())
                display_area.delete(0,END)    
                display_area.insert(0,"Record Updated!!")
                for row in DbOperations.display_all():
                        display_area.insert(END,row)
        except TclError:
                display_area.delete(0,END)
                display_area.insert(0,"Enter year and isbn as integer")

window=Tk()

window.wm_title("Abhijeet's Bookstore")
title_label = Label(window,text="Title")
title_label.grid(row=0, column=0)

title_value=StringVar()
title_input = Entry(window,textvariable=title_value)
title_input.grid(row=0, column=1)

author_label = Label(window,text="Author")
author_label.grid(row=0,column=2)

author_value=StringVar()
author_input=Entry(window, textvariable=author_value)
author_input.grid(row=0, column=3)

year_label = Label(window,text="Year")
year_label.grid(row=1, column=0)

year_value=IntVar()
year_input = Entry(window,textvariable=year_value)
year_input.grid(row=1, column=1)

isbn_label=Label(window,text="ISBN")
isbn_label.grid(row=1,column=2)

isbn_value=IntVar()
isbn_input=Entry(window,textvariable=isbn_value)
isbn_input.grid(row=1,column=3)

view_button=Button(window,text="View All",width=15,command=view_all)
view_button.grid(row=2,column=3)

search_button=Button(window,text="Search Entry",command=search,width=15)
search_button.grid(row=3,column=3)

add_button=Button(window,text="Add Entry", command=insert,width=15)
add_button.grid(row=4,column=3)

update_button=Button(window,text="Update Selected",command=update,width=15)
update_button.grid(row=5,column=3)

delete_button=Button(window,text="Delete Selected",command=delete,width=15)
delete_button.grid(row=6,column=3)

close_button=Button(window,text="Close",command=window.destroy,width=15)
close_button.grid(row=7,column=3)

display_area=Listbox(window,height=5, width=50)
display_area.grid(row=2,column=1,rowspan=6,columnspan=1)

sb=Scrollbar(window)
sb.grid(row=2,column=2,rowspan=6,columnspan=1)

display_area.configure(yscrollcommand=sb.set)
sb.configure(command=display_area.yview)

display_area.bind('<<ListboxSelect>>',row_id)
window.mainloop()